export default {
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
        cssnano: {}
    },
}
