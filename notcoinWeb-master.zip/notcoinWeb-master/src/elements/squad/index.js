export { default as Squad } from './Squad.svelte';
