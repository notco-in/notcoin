<div class="absolute w-full h-full hidden lg:block">
  <img
      class="absolute w-[44px] -top-6 left-[25rem]"
      src="/images/penny.webp"
      draggable="false"
      alt="burned icon"
  />
  <img
      class="absolute w-[22px] top-16 left-[27rem]"
      src="/images/penny.webp"
      draggable="false"
      alt="burned icon"
  />
  <img
      class="absolute w-[27px] top-24 left-[24rem]"
      src="/images/penny.webp"
      draggable="false"
      alt="burned icon"
  />
</div>
