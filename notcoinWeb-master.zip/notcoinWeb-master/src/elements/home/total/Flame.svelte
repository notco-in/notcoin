<div class="absolute w-full h-full hidden lg:block">
  <img
      class="absolute w-[20px] -top-[2.2rem] left-6"
      src="/images/flame.webp"
      draggable="false"
      alt="burned icon"
  />
  <img
      class="absolute w-[40px] -top-6 -left-8"
      src="/images/flame.webp"
      draggable="false"
      alt="burned icon"
  />
  <img
      class="absolute w-[26px] -top-[2.3rem] left-80"
      src="/images/flame.webp"
      draggable="false"
      alt="burned icon"
  />
  <img
      class="absolute w-[38px] -top-6 left-[23rem]"
      src="/images/flame.webp"
      draggable="false"
      alt="burned icon"
  />
  <img
      class="absolute w-[42px] top-20 left-[22rem]"
      src="/images/flame.webp"
      draggable="false"
      alt="burned icon"
  />
  <img
      class="absolute w-[32px] top-12 left-[26rem]"
      src="/images/flame.webp"
      draggable="false"
      alt="burned icon"
  />
</div>
