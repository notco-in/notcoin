<div class="flex gap-1 flex-col mb-12 items-center mt-40 md:text-[.5rem] md:mb-16 md:mt-48">
    <h1 class="font-extrabold text-4xl md:text-6xl">Notcoin</h1>
    <h2 class="text-base text-[#ebebf599] md:text-lg">the biggest web3 game</h2>
</div>
