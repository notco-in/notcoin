<div class="bg-[#ffffff1f] rounded-xl w-full flex z-5 backdrop-blur-sm font-semibold text-[#ebebf599] gap-3 pl-6 py-3 mb-3">
    <div>#</div>
    <div class="text-xs uppercase tracking-widest mt-1">
        <slot></slot>
    </div>
</div>
