<div class="item flex items-center select-none min-h-16 p-2 pl-4">
    <div class="skeleton-bg skeleton-animation w-5 min-w-5 h-2 ml-1 mr-3.5 rounded-2xl"></div>
    <div class="skeleton-bg skeleton-animation w-12 h-12 rounded-full mr-3 shrink-0"></div>
    <div class="w-full">
        <div class="skeleton-bg skeleton-animation w-[40%] h-2 mb-4 rounded-2xl"></div>
        <div class="skeleton-bg skeleton-animation w-[70%] h-2 rounded-2xl"></div>
    </div>
</div>
