<div class="text-center py-[48px] px-0 my-0 mx-auto">
    <div class="text-[70px] leading-[70px] mb-[16px]">🚧</div>
    <div class="text-[15px] leading-[20px] font-normal text-[#ebebf599]">
        under maintenance
    </div>
</div>
