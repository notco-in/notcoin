<svg
    xmlns="http://www.w3.org/2000/svg"
    version="1.1"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    width="512"
    height="512"
    x="0"
    y="0"
    viewBox="0 0 24 24"
    style="enable-background:new 0 0 512 512"
    xml:space="preserve"
    stroke="currentColor"
    fill="currentColor"
    {...$$restProps}
>
    <g>
        <path
            stroke-width=".1"
            d="M21.003 10a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H15a1 1 0 1 0 0 2h3.59l-8.607 8.607a1 1 0 0 0 1.414 1.414l8.607-8.607V9a1 1 0 0 0 1 1zM5 5a3 3 0 0 0-3 3v11a3 3 0 0 0 3 3h11a3 3 0 0 0 3-3v-6a1 1 0 1 0-2 0v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h6a1 1 0 1 0 0-2z"
        >
        </path>
    </g>
</svg>
