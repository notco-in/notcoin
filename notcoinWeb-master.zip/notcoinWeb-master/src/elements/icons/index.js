export { default as Open } from "./Open.svelte";

export { default as Telegram } from "./Telegram.svelte";
export { default as X } from "./X.svelte";
